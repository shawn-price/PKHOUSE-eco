'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import MortgageCalculatorForm from '@/components/consumer/mortgage-calculator'

export default function MortgageToolPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/consumer">
            <div className="cursor-pointer">
              <h1 className="text-2xl font-bold text-foreground">Pick Your House</h1>
              <p className="text-sm text-muted-foreground">Mortgage Calculator</p>
            </div>
          </Link>
          <Link href="/consumer">
            <Button variant="outline">Back to Home</Button>
          </Link>
        </div>
      </header>

      {/* Calculator Section */}
      <section className="px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-foreground mb-2">
              Mortgage Calculator
            </h2>
            <p className="text-muted-foreground">
              Calculate your monthly mortgage payments based on property price, down payment, and interest rate.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Calculator Form */}
            <div className="lg:col-span-2">
              <MortgageCalculatorForm />
            </div>

            {/* Info Panel */}
            <div className="space-y-6">
              {/* About */}
              <div className="p-6 bg-card border rounded-lg">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  How it works
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">1.</span>
                    <span>Enter the property price</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">2.</span>
                    <span>Set your down payment amount</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">3.</span>
                    <span>Choose loan term and interest rate</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-bold">4.</span>
                    <span>See your monthly payment breakdown</span>
                  </li>
                </ul>
              </div>

              {/* CBN Rates */}
              <div className="p-6 bg-primary/5 border border-primary/20 rounded-lg">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  Current CBN Rates
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Prime Rate:</span>
                    <span className="font-semibold">18.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Mortgage Rate:</span>
                    <span className="font-semibold">16-20%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3 pt-3 border-t">
                    Rates shown are approximate and based on CBN recent data. Consult with banks for exact rates.
                  </p>
                </div>
              </div>

              {/* Tips */}
              <div className="p-6 bg-card border rounded-lg">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  Tips
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Higher down payment = Lower monthly payment</li>
                  <li>• Shorter terms = Higher payments, less interest</li>
                  <li>• Get pre-approved before house hunting</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
