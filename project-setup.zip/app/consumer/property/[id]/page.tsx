'use server'

import { db } from '@/lib/db'
import { properties, agents } from '@/lib/db/schema'
import { eq } from 'drizzle-orm'
import { formatCurrency } from '@/lib/utils'
import LeadCaptureForm from '@/components/consumer/lead-capture-form'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

async function getPropertyDetails(id: string) {
  try {
    const result = await db
      .select()
      .from(properties)
      .where(eq(properties.id, id))
      .limit(1)

    return result[0] || null
  } catch (error) {
    console.error('Error fetching property:', error)
    return null
  }
}

async function getAgentInfo(agentId: string) {
  try {
    const result = await db
      .select()
      .from(agents)
      .where(eq(agents.id, agentId))
      .limit(1)

    return result[0] || null
  } catch (error) {
    console.error('Error fetching agent:', error)
    return null
  }
}

export default async function PropertyDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const property = await getPropertyDetails(id)

  if (!property) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Property not found</h1>
          <p className="text-muted-foreground mb-6">
            The property you&apos;re looking for doesn&apos;t exist or has been removed.
          </p>
          <Link href="/consumer">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  const agent = property.agentId ? await getAgentInfo(property.agentId) : null

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/consumer">
            <div className="cursor-pointer">
              <h1 className="text-2xl font-bold text-foreground">Pick Your House</h1>
            </div>
          </Link>
          <div className="flex gap-3">
            <Link href="/consumer/search">
              <Button variant="outline">Back to Search</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Property Details */}
      <section className="px-6 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Image */}
              <div className="mb-6 rounded-lg overflow-hidden bg-muted h-96 flex items-center justify-center">
                <span className="text-muted-foreground">Property Image</span>
              </div>

              {/* Title & Basic Info */}
              <div className="mb-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold text-foreground mb-2">
                      {property.title}
                    </h1>
                    <p className="text-lg text-muted-foreground">
                      {property.address}
                      {property.city && `, ${property.city}`}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Price</p>
                    <p className="text-3xl font-bold text-primary">
                      {formatCurrency(property.price)}
                    </p>
                  </div>
                </div>

                {property.propertyType && (
                  <span className="inline-block px-3 py-1 bg-primary text-white text-sm font-semibold rounded">
                    {property.propertyType}
                  </span>
                )}
              </div>

              {/* Features Grid */}
              <div className="grid grid-cols-4 gap-4 mb-8 p-6 bg-card border rounded-lg">
                {property.bedrooms && (
                  <div className="text-center">
                    <p className="text-3xl font-bold text-primary mb-1">
                      {property.bedrooms}
                    </p>
                    <p className="text-sm text-muted-foreground">Bedrooms</p>
                  </div>
                )}
                {property.bathrooms && (
                  <div className="text-center">
                    <p className="text-3xl font-bold text-primary mb-1">
                      {property.bathrooms}
                    </p>
                    <p className="text-sm text-muted-foreground">Bathrooms</p>
                  </div>
                )}
                {property.squareFeet && (
                  <div className="text-center">
                    <p className="text-3xl font-bold text-primary mb-1">
                      {property.squareFeet.toLocaleString()}
                    </p>
                    <p className="text-sm text-muted-foreground">Sq Ft</p>
                  </div>
                )}
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary mb-1">Active</p>
                  <p className="text-sm text-muted-foreground">Status</p>
                </div>
              </div>

              {/* Description */}
              {property.description && (
                <div className="mb-8">
                  <h2 className="text-xl font-semibold text-foreground mb-3">
                    About this property
                  </h2>
                  <p className="text-muted-foreground whitespace-pre-line">
                    {property.description}
                  </p>
                </div>
              )}

              {/* Agent Info */}
              {agent && (
                <div className="p-6 bg-card border rounded-lg">
                  <h2 className="text-lg font-semibold text-foreground mb-4">
                    Listing Agent
                  </h2>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-sm font-semibold">
                        {agent.companyName?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">
                        {agent.companyName || 'Agent'}
                      </p>
                      {agent.phoneNumber && (
                        <p className="text-sm text-muted-foreground">{agent.phoneNumber}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar - Lead Form */}
            <div className="lg:col-span-1">
              <LeadCaptureForm propertyId={property.id} />
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
