'use server'

import { db } from '@/lib/db'
import { properties } from '@/lib/db/schema'
import { eq, and, gte, lte, like, sql } from 'drizzle-orm'
import { Button } from '@/components/ui/button'
import PropertyCard from '@/components/consumer/property-card'
import PropertySearchForm from '@/components/consumer/property-search-form'
import Link from 'next/link'

interface SearchParams {
  location?: string
  minPrice?: string
  maxPrice?: string
  propertyType?: string
  bedrooms?: string
}

async function searchProperties(params: SearchParams) {
  try {
    let query = db
      .select()
      .from(properties)
      .where(eq(properties.listingStatus, 'active'))

    const conditions = [eq(properties.listingStatus, 'active')]

    if (params.location) {
      conditions.push(
        sql`${properties.address} ILIKE ${`%${params.location}%`} OR ${properties.city} ILIKE ${`%${params.location}%`}`
      )
    }

    if (params.minPrice) {
      conditions.push(gte(properties.price, parseFloat(params.minPrice)))
    }

    if (params.maxPrice) {
      conditions.push(lte(properties.price, parseFloat(params.maxPrice)))
    }

    if (params.propertyType) {
      conditions.push(eq(properties.propertyType, params.propertyType))
    }

    if (params.bedrooms) {
      conditions.push(gte(properties.bedrooms, parseInt(params.bedrooms)))
    }

    const whereClause = conditions.length > 1 ? and(...conditions) : conditions[0]

    const result = await db
      .select()
      .from(properties)
      .where(whereClause)
      .limit(50)

    return result
  } catch (error) {
    console.error('Error searching properties:', error)
    return []
  }
}

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const params = await searchParams
  const results = await searchProperties(params)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/consumer">
            <div className="cursor-pointer">
              <h1 className="text-2xl font-bold text-foreground">Pick Your House</h1>
              <p className="text-sm text-muted-foreground">Search Results</p>
            </div>
          </Link>
          <Link href="/consumer">
            <Button variant="outline">Home</Button>
          </Link>
        </div>
      </header>

      {/* Search Form */}
      <section className="border-b bg-card px-6 py-6">
        <div className="max-w-7xl mx-auto">
          <PropertySearchForm />
        </div>
      </section>

      {/* Results */}
      <section className="px-6 py-12">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-foreground mb-2">
              Search Results
            </h2>
            <p className="text-muted-foreground">
              Found {results.length} {results.length === 1 ? 'property' : 'properties'}
              {params.location && ` in ${params.location}`}
            </p>
          </div>

          {results.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <h3 className="text-xl font-semibold text-foreground mb-2">
                No properties found
              </h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search criteria or browse featured listings
              </p>
              <Link href="/consumer">
                <Button>Back to Home</Button>
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
