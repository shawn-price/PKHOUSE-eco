'use server'

import { db } from '@/lib/db'
import { properties } from '@/lib/db/schema'
import { eq } from 'drizzle-orm'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import PropertyCard from '@/components/consumer/property-card'
import PropertySearchForm from '@/components/consumer/property-search-form'

async function getFeaturedProperties() {
  try {
    const result = await db
      .select()
      .from(properties)
      .where(eq(properties.listingStatus, 'active'))
      .limit(6)
    
    return result
  } catch (error) {
    console.error('Error fetching featured properties:', error)
    return []
  }
}

export default async function ConsumerHome() {
  const featuredProperties = await getFeaturedProperties()

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Pick Your House</h1>
            <p className="text-sm text-muted-foreground">Discover your perfect property in Abuja</p>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/consumer/map">
              <Button variant="outline" className="text-sm">Map View</Button>
            </Link>
            <Link href="/consumer/tools/mortgage">
              <Button variant="outline" className="text-sm">Mortgage Calculator</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Search Section */}
      <section className="bg-gradient-to-r from-primary to-primary/90 px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h2 className="text-3xl font-bold text-white mb-2">Find Your Dream Property</h2>
            <p className="text-white/80">Search thousands of verified properties across Abuja</p>
          </div>
          <PropertySearchForm />
        </div>
      </section>

      {/* Featured Properties */}
      <section className="px-6 py-16">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Featured Listings</h2>
              <p className="text-sm text-muted-foreground">Recently updated properties</p>
            </div>
            <Link href="/consumer/search">
              <Button>View All Properties</Button>
            </Link>
          </div>

          {featuredProperties.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProperties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No properties available at the moment.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-card border-t px-6 py-12">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Can&apos;t find what you&apos;re looking for?
          </h2>
          <p className="text-muted-foreground mb-6">
            Get connected with verified real estate agents who can help guide you through the process.
          </p>
          <Button size="lg">Get Expert Help</Button>
        </div>
      </section>
    </div>
  )
}
