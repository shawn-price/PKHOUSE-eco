'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import PropertyForm from '@/components/property-form'

export default async function NewPropertyPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center gap-4">
          <Link href="/properties">
            <Button variant="ghost">&larr; Back</Button>
          </Link>
          <h1 className="text-2xl font-bold">List New Property</h1>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-2xl mx-auto">
          <PropertyForm />
        </div>
      </main>
    </div>
  )
}
