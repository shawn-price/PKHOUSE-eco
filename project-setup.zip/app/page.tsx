'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { getAgentProfile } from '@/app/actions/agents'

export default async function Home() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const agentProfile = await getAgentProfile()
  if (!agentProfile) {
    redirect('/agent/setup')
  }

  async function signOut() {
    'use server'
    await auth.api.signOut({ headers: await headers() })
    redirect('/sign-in')
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Pick Your House Eco</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              {session.user.email}
            </span>
            <form action={signOut}>
              <Button variant="outline" type="submit">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xl font-semibold mb-6">Agent Dashboard</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2">Active Listings</h3>
              <p className="text-2xl font-bold">0</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2">Open Deals</h3>
              <p className="text-2xl font-bold">0</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2">Commission Pending</h3>
              <p className="text-2xl font-bold">₦0.00</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-8 md:grid-cols-4">
            <a href="/properties" className="flex flex-col items-center gap-2 p-4 rounded-lg border hover:bg-accent transition-colors">
              <div className="text-2xl font-bold">0</div>
              <div className="text-xs text-muted-foreground text-center">Properties Listed</div>
            </a>
            <a href="/deals" className="flex flex-col items-center gap-2 p-4 rounded-lg border hover:bg-accent transition-colors">
              <div className="text-2xl font-bold">0</div>
              <div className="text-xs text-muted-foreground text-center">Active Deals</div>
            </a>
            <a href="/network" className="flex flex-col items-center gap-2 p-4 rounded-lg border hover:bg-accent transition-colors">
              <div className="text-2xl font-bold">0</div>
              <div className="text-xs text-muted-foreground text-center">Partnerships</div>
            </a>
            <div className="flex flex-col items-center gap-2 p-4 rounded-lg border">
              <div className="text-2xl font-bold text-primary">₦0</div>
              <div className="text-xs text-muted-foreground text-center">Commissions</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <a href="/properties/new">
              <Button className="w-full">List New Property</Button>
            </a>
            <a href="/network">
              <Button variant="outline" className="w-full">Find Partners</Button>
            </a>
            <a href="/deals">
              <Button variant="outline" className="w-full">Manage Deals</Button>
            </a>
            <a href="/properties">
              <Button variant="outline" className="w-full">View Properties</Button>
            </a>
          </div>
        </div>
      </main>
    </div>
  )
}
