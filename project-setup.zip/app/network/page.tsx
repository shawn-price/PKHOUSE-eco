'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { getAgentDirectory, getMyPartnerships } from '@/app/actions/partnerships'
import AgentCard from '@/components/agent-card'

export default async function NetworkPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const agents = await getAgentDirectory()
  const partnerships = await getMyPartnerships()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <h1 className="text-2xl font-bold">Agent Network</h1>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <h2 className="text-xl font-semibold mb-6">My Partnerships ({partnerships.length})</h2>
            {partnerships.length === 0 ? (
              <p className="text-muted-foreground">No active partnerships yet.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {partnerships.map((partnership) => (
                  <div key={partnership.id} className="border rounded-lg p-4 bg-card">
                    <h3 className="font-semibold">{partnership.partnerName}</h3>
                    <p className="text-sm text-muted-foreground">{partnership.partnerEmail}</p>
                    <span className={`inline-block mt-2 px-2 py-1 rounded text-xs font-semibold ${
                      partnership.status === 'active' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {partnership.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-6">Available Agents</h2>
            {agents.length === 0 ? (
              <p className="text-muted-foreground">No other agents available.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {agents.map((agent) => (
                  <AgentCard key={agent.id} agent={agent} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
