'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { getMyDeals } from '@/app/actions/deals'
import DealCard from '@/components/deal-card'

export default async function DealsPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const myDeals = await getMyDeals()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">My Deals</h1>
          <Link href="/deals/new">
            <Button>New Deal</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-4xl mx-auto">
          {myDeals.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">
                You haven&apos;t created any deals yet.
              </p>
              <Link href="/deals/new">
                <Button>Create Your First Deal</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {myDeals.map((deal) => (
                <DealCard key={deal.id} deal={deal} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
