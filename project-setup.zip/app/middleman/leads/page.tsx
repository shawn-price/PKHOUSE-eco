'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { getMiddlemanProfile } from '@/app/actions/middlemen'
import { getSourcedLeads } from '@/app/actions/middleman-leads'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { SourcedLeadCard } from '@/components/middleman/sourced-lead-card'

export default async function MiddlemanLeadsPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const profile = await getMiddlemanProfile()
  if (!profile) {
    redirect('/middleman/setup')
  }

  const leads = await getSourcedLeads()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">My Sourced Leads</h1>
          <Link href="/middleman">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Your Leads</h2>
            <Link href="/middleman/leads/new">
              <Button>Create New Lead</Button>
            </Link>
          </div>

          {leads.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No leads yet</p>
              <Link href="/middleman/leads/new">
                <Button>Source Your First Lead</Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {leads.map(lead => (
                <SourcedLeadCard key={lead.id} lead={lead} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
