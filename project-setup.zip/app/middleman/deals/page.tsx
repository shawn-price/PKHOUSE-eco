'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { getMiddlemanProfile } from '@/app/actions/middlemen'
import { getMiddlemanDeals } from '@/app/actions/middleman-deals'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default async function MiddlemanDealsPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const profile = await getMiddlemanProfile()
  if (!profile) {
    redirect('/middleman/setup')
  }

  const deals = await getMiddlemanDeals()

  const statusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-50 text-yellow-700'
      case 'in_progress':
        return 'bg-blue-50 text-blue-700'
      case 'closed':
        return 'bg-green-50 text-green-700'
      case 'cancelled':
        return 'bg-red-50 text-red-700'
      default:
        return 'bg-gray-50 text-gray-700'
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Active Deals</h1>
          <Link href="/middleman">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-xl font-semibold mb-6">Your Deal Pipeline</h2>

          {deals.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No deals yet</p>
              <Link href="/middleman/leads">
                <Button>Create Your First Deal</Button>
              </Link>
            </div>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Deal ID</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Agent</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Commission %</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {deals.map(({ middlemanDeal, agent }) => (
                    <tr key={middlemanDeal.id} className="border-t hover:bg-muted/50">
                      <td className="px-4 py-3 text-sm font-medium">
                        {middlemanDeal.dealId.slice(0, 8)}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {agent?.companyName || 'N/A'}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {middlemanDeal.commissionPercentage}%
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${statusColor(middlemanDeal.dealStatus)}`}>
                          {middlemanDeal.dealStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <Link href={`/middleman/deals/${middlemanDeal.id}`}>
                          <Button variant="outline" size="sm">View</Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
