'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { getMiddlemanProfile, getMiddlemanStats } from '@/app/actions/middlemen'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default async function MiddlemanDashboardPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const profile = await getMiddlemanProfile()
  if (!profile) {
    redirect('/middleman/setup')
  }

  const stats = await getMiddlemanStats()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Middleman Network</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              {profile.firstName} {profile.lastName}
            </span>
            <form action={async () => {
              'use server'
              await auth.api.signOut({ headers: await headers() })
              redirect('/sign-in')
            }}>
              <Button variant="outline" type="submit">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-xl font-semibold mb-6">Dashboard</h2>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">Wallet Balance</h3>
              <p className="text-2xl font-bold">₦{stats?.walletBalance || '0.00'}</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">Total Earnings</h3>
              <p className="text-2xl font-bold">₦{stats?.totalEarnings || '0.00'}</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">Deals Completed</h3>
              <p className="text-2xl font-bold">{stats?.dealsCompleted || '0'}</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">Rating</h3>
              <p className="text-2xl font-bold">⭐ {stats?.rating || '5.00'}</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <Link href="/middleman/leads">
              <Button className="w-full" size="lg">
                Source New Leads
              </Button>
            </Link>
            <Link href="/middleman/deals">
              <Button variant="outline" className="w-full" size="lg">
                View Active Deals
              </Button>
            </Link>
            <Link href="/middleman/commissions">
              <Button variant="outline" className="w-full" size="lg">
                Commission History
              </Button>
            </Link>
            <Link href="/middleman/profile">
              <Button variant="outline" className="w-full" size="lg">
                Edit Profile
              </Button>
            </Link>
          </div>

          {/* Welcome Card */}
          <div className="border rounded-lg p-6 bg-card">
            <h3 className="text-lg font-semibold mb-2">How it Works</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>✓ Source leads from our consumer platform</li>
              <li>✓ Match leads with properties from agents</li>
              <li>✓ Earn {profile.commissionRate}% commission on successful deals</li>
              <li>✓ Track earnings in real-time dashboard</li>
              <li>✓ Withdraw funds to your wallet</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  )
}
