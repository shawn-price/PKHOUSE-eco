'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { getMiddlemanProfile } from '@/app/actions/middlemen'
import { MiddlemanSetupForm } from '@/components/middleman/setup-form'

export default async function MiddlemanSetupPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const profile = await getMiddlemanProfile()
  if (profile) {
    redirect('/middleman')
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Join the Middleman Network</h1>
          <p className="text-muted-foreground">
            Complete your profile to start sourcing leads and earning commissions
          </p>
        </div>
        <MiddlemanSetupForm />
      </div>
    </div>
  )
}
