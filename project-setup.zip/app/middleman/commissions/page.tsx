'use server'

import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { getMiddlemanProfile } from '@/app/actions/middlemen'
import { getMiddlemanCommissions, getCommissionStats } from '@/app/actions/middleman-commissions'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { formatCurrency } from '@/lib/utils'

export default async function MiddlemanCommissionsPage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect('/sign-in')
  }

  const profile = await getMiddlemanProfile()
  if (!profile) {
    redirect('/middleman/setup')
  }

  const commissions = await getMiddlemanCommissions()
  const stats = await getCommissionStats()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Commission Ledger</h1>
          <Link href="/middleman">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">Pending</h3>
              <p className="text-2xl font-bold">{formatCurrency(stats.pending)}</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">In Escrow</h3>
              <p className="text-2xl font-bold">{formatCurrency(stats.inEscrow)}</p>
            </div>
            <div className="border rounded-lg p-4 bg-card">
              <h3 className="font-semibold mb-2 text-sm text-muted-foreground">Released</h3>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(stats.released)}</p>
            </div>
          </div>

          {/* Commission History */}
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Deal ID</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Agent Commission</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Your Commission</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Created</th>
                </tr>
              </thead>
              <tbody>
                {commissions.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                      No commissions yet
                    </td>
                  </tr>
                ) : (
                  commissions.map(({ commission, deal }) => (
                    <tr key={commission.id} className="border-t hover:bg-muted/50">
                      <td className="px-4 py-3 text-sm">{deal?.id.slice(0, 8) || 'N/A'}</td>
                      <td className="px-4 py-3 text-sm font-medium">
                        {formatCurrency(commission.agentCommission)}
                      </td>
                      <td className="px-4 py-3 text-sm font-medium">
                        {formatCurrency(commission.middlemanCommissionAmount)}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${
                          commission.commissionStatus === 'released' ? 'bg-green-100 text-green-800' :
                          commission.commissionStatus === 'in_escrow' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {commission.commissionStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">
                        {new Date(commission.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  )
}
