'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { createPartnershipRequest } from '@/app/actions/partnerships'

export default function AgentCard({ agent }: { agent: any }) {
  const [isLoading, setIsLoading] = useState(false)

  async function handlePartnershipRequest() {
    setIsLoading(true)
    try {
      await createPartnershipRequest({
        partnerAgentId: agent.id,
        commissionSplit: '50',
        notes: 'Partnership request from agent network',
      })
      alert('Partnership request sent!')
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to send request')
    }
    setIsLoading(false)
  }

  return (
    <div className="border rounded-lg p-6 bg-card hover:shadow-lg transition-shadow">
      <h3 className="font-semibold text-lg mb-2">{agent.userName}</h3>
      <p className="text-sm text-muted-foreground mb-2">{agent.userEmail}</p>

      {agent.companyName && (
        <p className="text-sm font-medium mb-2">{agent.companyName}</p>
      )}

      {agent.bio && (
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{agent.bio}</p>
      )}

      {agent.phoneNumber && (
        <p className="text-sm mb-3">{agent.phoneNumber}</p>
      )}

      <div className="flex items-center gap-2 mb-4">
        <span
          className={`px-2 py-1 rounded text-xs font-semibold ${
            agent.verificationStatus === 'verified'
              ? 'bg-green-100 text-green-800'
              : 'bg-yellow-100 text-yellow-800'
          }`}
        >
          {agent.verificationStatus}
        </span>
      </div>

      <Button
        onClick={handlePartnershipRequest}
        disabled={isLoading}
        className="w-full"
      >
        {isLoading ? 'Sending...' : 'Send Partnership Request'}
      </Button>
    </div>
  )
}
