'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { formatCurrency } from '@/lib/utils'
import { Heart } from 'lucide-react'
import Image from 'next/image'

interface PropertyCardProps {
  property: {
    id: string
    title: string
    address: string
    city?: string
    price?: string | number | null
    bedrooms?: number | null
    bathrooms?: number | null
    squareFeet?: number | null
    propertyType?: string | null
    imageUrls?: string[] | null
  }
}

export default function PropertyCard({ property }: PropertyCardProps) {
  const [isSaved, setIsSaved] = useState(false)
  const imageUrl = property.imageUrls?.[0] || '/placeholder-property.jpg'

  return (
    <div className="rounded-lg border bg-card overflow-hidden hover:shadow-lg transition-shadow">
      {/* Image Section */}
      <div className="relative h-48 bg-muted overflow-hidden group">
        <div className="w-full h-full relative bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
          <span className="text-gray-400 text-sm">Property Image</span>
        </div>
        <button
          onClick={() => setIsSaved(!isSaved)}
          className="absolute top-3 right-3 p-2 rounded-full bg-white/90 hover:bg-white transition-colors"
          aria-label="Save property"
        >
          <Heart
            className={`w-5 h-5 ${isSaved ? 'fill-red-500 text-red-500' : 'text-gray-400'}`}
          />
        </button>
        {property.propertyType && (
          <span className="absolute top-3 left-3 px-2 py-1 bg-primary text-white text-xs font-semibold rounded">
            {property.propertyType}
          </span>
        )}
      </div>

      {/* Content Section */}
      <div className="p-4">
        <div className="mb-3">
          <Link href={`/consumer/property/${property.id}`}>
            <h3 className="font-semibold text-foreground hover:text-primary transition-colors line-clamp-2">
              {property.title}
            </h3>
          </Link>
          <p className="text-sm text-muted-foreground line-clamp-1">{property.address}</p>
          {property.city && (
            <p className="text-xs text-muted-foreground">{property.city}</p>
          )}
        </div>

        {/* Features */}
        <div className="flex gap-4 text-sm text-muted-foreground mb-4 py-2 border-t border-b">
          {property.bedrooms && (
            <div>
              <span className="font-semibold text-foreground">{property.bedrooms}</span>
              <span className="text-xs"> beds</span>
            </div>
          )}
          {property.bathrooms && (
            <div>
              <span className="font-semibold text-foreground">{property.bathrooms}</span>
              <span className="text-xs"> baths</span>
            </div>
          )}
          {property.squareFeet && (
            <div>
              <span className="font-semibold text-foreground">
                {(property.squareFeet / 1000).toFixed(1)}k
              </span>
              <span className="text-xs"> sqft</span>
            </div>
          )}
        </div>

        {/* Price and CTA */}
        <div className="flex items-center justify-between">
          {property.price && (
            <div>
              <p className="text-xs text-muted-foreground">Price</p>
              <p className="text-lg font-bold text-primary">
                {formatCurrency(property.price)}
              </p>
            </div>
          )}
          <Link href={`/consumer/property/${property.id}`}>
            <Button size="sm">View Details</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
