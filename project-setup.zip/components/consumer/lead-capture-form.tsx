'use client'

import { useState } from 'react'
import { createLead } from '@/app/actions/leads'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

interface LeadCaptureFormProps {
  propertyId: string
}

export default function LeadCaptureForm({ propertyId }: LeadCaptureFormProps) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    interestLevel: 'interested' as const,
    contactPreference: 'email' as const,
    message: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError('')

    try {
      const result = await createLead({
        propertyId,
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        interestLevel: formData.interestLevel,
        contactPreference: formData.contactPreference,
        message: formData.message,
      })

      if (result.success) {
        setSubmitted(true)
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          interestLevel: 'interested',
          contactPreference: 'email',
          message: '',
        })

        setTimeout(() => setSubmitted(false), 5000)
      } else {
        setError(result.error || 'Failed to submit inquiry')
      }
    } catch (err) {
      setError('An error occurred. Please try again.')
      console.error(err)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <div className="p-6 bg-card border rounded-lg">
        <div className="text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-green-600 text-xl">✓</span>
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            Thank you!
          </h3>
          <p className="text-sm text-muted-foreground">
            We&apos;ve received your inquiry. An agent will contact you shortly.
          </p>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="sticky top-6 p-6 bg-card border rounded-lg">
      <h2 className="text-lg font-semibold text-foreground mb-4">
        Interested in this property?
      </h2>

      <div className="space-y-4">
        {/* Name Fields */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="firstName" className="text-sm">
              First Name
            </Label>
            <Input
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              placeholder="John"
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="lastName" className="text-sm">
              Last Name
            </Label>
            <Input
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              placeholder="Doe"
              className="mt-1"
            />
          </div>
        </div>

        {/* Email */}
        <div>
          <Label htmlFor="email" className="text-sm">
            Email <span className="text-red-500">*</span>
          </Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="your@email.com"
            required
            className="mt-1"
          />
        </div>

        {/* Phone */}
        <div>
          <Label htmlFor="phone" className="text-sm">
            Phone
          </Label>
          <Input
            id="phone"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            placeholder="+234 (0) 1234567890"
            className="mt-1"
          />
        </div>

        {/* Interest Level */}
        <div>
          <Label htmlFor="interestLevel" className="text-sm">
            Interest Level
          </Label>
          <select
            id="interestLevel"
            name="interestLevel"
            value={formData.interestLevel}
            onChange={handleChange}
            className="w-full mt-1 px-3 py-2 border border-input rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="interested">Just Interested</option>
            <option value="very_interested">Very Interested</option>
            <option value="serious">Serious Buyer</option>
          </select>
        </div>

        {/* Contact Preference */}
        <div>
          <Label htmlFor="contactPreference" className="text-sm">
            Preferred Contact
          </Label>
          <select
            id="contactPreference"
            name="contactPreference"
            value={formData.contactPreference}
            onChange={handleChange}
            className="w-full mt-1 px-3 py-2 border border-input rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="email">Email</option>
            <option value="phone">Phone</option>
            <option value="both">Both</option>
          </select>
        </div>

        {/* Message */}
        <div>
          <Label htmlFor="message" className="text-sm">
            Message (Optional)
          </Label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Tell us about your interest..."
            rows={3}
            className="w-full mt-1 px-3 py-2 border border-input rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>

        {/* Error Message */}
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-700">
            {error}
          </div>
        )}

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full"
        >
          {isSubmitting ? 'Sending...' : 'Get More Information'}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          An agent will contact you to discuss this property.
        </p>
      </div>
    </form>
  )
}
