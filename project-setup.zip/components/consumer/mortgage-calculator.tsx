'use client'

import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'

interface MortgageDetails {
  monthlyPayment: number
  totalPayment: number
  totalInterest: number
  principalPayment: number
}

export default function MortgageCalculator() {
  const [formData, setFormData] = useState({
    propertyPrice: 10000000,
    downPayment: 2000000,
    interestRate: 18.5,
    loanTerm: 20,
  })

  const [results, setResults] = useState<MortgageDetails | null>(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }))
  }

  const calculateMortgage = () => {
    const loanAmount = formData.propertyPrice - formData.downPayment
    const monthlyRate = formData.interestRate / 100 / 12
    const numberOfPayments = formData.loanTerm * 12

    if (monthlyRate === 0) {
      const monthlyPayment = loanAmount / numberOfPayments
      setResults({
        monthlyPayment,
        totalPayment: loanAmount,
        totalInterest: 0,
        principalPayment: loanAmount,
      })
      return
    }

    const monthlyPayment =
      (loanAmount *
        (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
      (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

    const totalPayment = monthlyPayment * numberOfPayments
    const totalInterest = totalPayment - loanAmount

    setResults({
      monthlyPayment,
      totalPayment,
      totalInterest,
      principalPayment: loanAmount,
    })
  }

  const handleReset = () => {
    setFormData({
      propertyPrice: 10000000,
      downPayment: 2000000,
      interestRate: 18.5,
      loanTerm: 20,
    })
    setResults(null)
  }

  return (
    <div className="p-6 bg-card border rounded-lg">
      <div className="space-y-6">
        {/* Input Fields */}
        <div className="space-y-4">
          {/* Property Price */}
          <div>
            <Label htmlFor="propertyPrice" className="text-sm font-medium">
              Property Price (₦)
            </Label>
            <Input
              id="propertyPrice"
              name="propertyPrice"
              type="number"
              value={formData.propertyPrice}
              onChange={handleInputChange}
              className="mt-1"
              step="100000"
            />
            <p className="text-xs text-muted-foreground mt-1">
              {(formData.propertyPrice / 1000000).toFixed(1)}M
            </p>
          </div>

          {/* Down Payment */}
          <div>
            <Label htmlFor="downPayment" className="text-sm font-medium">
              Down Payment (₦)
            </Label>
            <Input
              id="downPayment"
              name="downPayment"
              type="number"
              value={formData.downPayment}
              onChange={handleInputChange}
              className="mt-1"
              step="100000"
            />
            <p className="text-xs text-muted-foreground mt-1">
              {((formData.downPayment / formData.propertyPrice) * 100).toFixed(1)}%
              down payment
            </p>
          </div>

          {/* Interest Rate */}
          <div>
            <Label htmlFor="interestRate" className="text-sm font-medium">
              Annual Interest Rate (%)
            </Label>
            <Input
              id="interestRate"
              name="interestRate"
              type="number"
              value={formData.interestRate}
              onChange={handleInputChange}
              className="mt-1"
              step="0.1"
              min="0"
              max="30"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Current CBN rates range from 16-20%
            </p>
          </div>

          {/* Loan Term */}
          <div>
            <Label htmlFor="loanTerm" className="text-sm font-medium">
              Loan Term (Years)
            </Label>
            <Input
              id="loanTerm"
              name="loanTerm"
              type="number"
              value={formData.loanTerm}
              onChange={handleInputChange}
              className="mt-1"
              step="1"
              min="1"
              max="40"
            />
          </div>
        </div>

        {/* Buttons */}
        <div className="flex gap-3">
          <Button onClick={calculateMortgage} className="flex-1">
            Calculate
          </Button>
          <Button onClick={handleReset} variant="outline" className="flex-1">
            Reset
          </Button>
        </div>

        {/* Results */}
        {results && (
          <div className="pt-6 border-t space-y-4">
            <h3 className="font-semibold text-foreground">Loan Breakdown</h3>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-primary/5 rounded-lg">
                <p className="text-xs text-muted-foreground">Monthly Payment</p>
                <p className="text-2xl font-bold text-primary mt-1">
                  ₦{results.monthlyPayment.toLocaleString('en-NG', {
                    maximumFractionDigits: 0,
                  })}
                </p>
              </div>

              <div className="p-3 bg-primary/5 rounded-lg">
                <p className="text-xs text-muted-foreground">Loan Amount</p>
                <p className="text-2xl font-bold text-primary mt-1">
                  ₦{results.principalPayment.toLocaleString('en-NG', {
                    maximumFractionDigits: 0,
                  })}
                </p>
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Interest Paid:</span>
                <span className="font-semibold text-foreground">
                  ₦{results.totalInterest.toLocaleString('en-NG', {
                    maximumFractionDigits: 0,
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Amount Paid:</span>
                <span className="font-semibold text-foreground">
                  ₦{results.totalPayment.toLocaleString('en-NG', {
                    maximumFractionDigits: 0,
                  })}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t">
                <span className="text-muted-foreground">Loan Duration:</span>
                <span className="font-semibold text-foreground">
                  {formData.loanTerm} years ({formData.loanTerm * 12} months)
                </span>
              </div>
            </div>

            {/* Amortization Summary */}
            <div className="pt-4 border-t space-y-2 text-xs">
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary"
                  style={{
                    width: `${(results.principalPayment / results.totalPayment) * 100}%`,
                  }}
                />
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Principal: {((results.principalPayment / results.totalPayment) * 100).toFixed(0)}%</span>
                <span>Interest: {((results.totalInterest / results.totalPayment) * 100).toFixed(0)}%</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
