'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function PropertySearchForm() {
  const router = useRouter()
  const [searchParams, setSearchParams] = useState({
    location: '',
    minPrice: '',
    maxPrice: '',
    propertyType: '',
    bedrooms: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setSearchParams((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    
    const params = new URLSearchParams()
    Object.entries(searchParams).forEach(([key, value]) => {
      if (value) params.append(key, value)
    })
    
    router.push(`/consumer/search?${params.toString()}`)
  }

  return (
    <form onSubmit={handleSearch} className="bg-white rounded-lg p-6 shadow-lg">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div>
          <Label htmlFor="location" className="text-sm font-medium text-gray-700 block mb-2">
            Location
          </Label>
          <Input
            id="location"
            name="location"
            placeholder="City, area, address"
            value={searchParams.location}
            onChange={handleChange}
            className="w-full"
          />
        </div>

        <div>
          <Label htmlFor="propertyType" className="text-sm font-medium text-gray-700 block mb-2">
            Property Type
          </Label>
          <select
            id="propertyType"
            name="propertyType"
            value={searchParams.propertyType}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">All Types</option>
            <option value="apartment">Apartment</option>
            <option value="house">House</option>
            <option value="land">Land</option>
            <option value="commercial">Commercial</option>
            <option value="office">Office</option>
          </select>
        </div>

        <div>
          <Label htmlFor="bedrooms" className="text-sm font-medium text-gray-700 block mb-2">
            Bedrooms
          </Label>
          <select
            id="bedrooms"
            name="bedrooms"
            value={searchParams.bedrooms}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Any</option>
            <option value="1">1+</option>
            <option value="2">2+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
            <option value="5">5+</option>
          </select>
        </div>

        <div>
          <Label htmlFor="minPrice" className="text-sm font-medium text-gray-700 block mb-2">
            Min Price
          </Label>
          <Input
            id="minPrice"
            name="minPrice"
            type="number"
            placeholder="Min"
            value={searchParams.minPrice}
            onChange={handleChange}
            className="w-full"
          />
        </div>

        <div className="flex items-end gap-2">
          <div className="flex-1">
            <Label htmlFor="maxPrice" className="text-sm font-medium text-gray-700 block mb-2">
              Max Price
            </Label>
            <Input
              id="maxPrice"
              name="maxPrice"
              type="number"
              placeholder="Max"
              value={searchParams.maxPrice}
              onChange={handleChange}
              className="w-full"
            />
          </div>
          <Button type="submit" className="w-full">
            Search
          </Button>
        </div>
      </div>
    </form>
  )
}
