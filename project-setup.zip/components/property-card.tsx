'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { formatCurrency } from '@/lib/utils'

export default function PropertyCard({ property }: { property: any }) {
  return (
    <div className="border rounded-lg overflow-hidden bg-card hover:shadow-lg transition-shadow">
      <div className="bg-muted h-48 flex items-center justify-center">
        {property.imageUrls && property.imageUrls.length > 0 ? (
          <img
            src={property.imageUrls[0]}
            alt={property.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-muted-foreground">No image</div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2">{property.title}</h3>
        
        <p className="text-sm text-muted-foreground mb-3">
          {property.address}
          {property.city && `, ${property.city}`}
        </p>

        {property.price && (
          <p className="text-lg font-bold mb-3 text-primary">
            {formatCurrency(property.price)}
          </p>
        )}

        <div className="grid grid-cols-3 gap-2 mb-4 text-sm">
          {property.bedrooms && (
            <div className="text-center">
              <div className="font-semibold">{property.bedrooms}</div>
              <div className="text-muted-foreground text-xs">Beds</div>
            </div>
          )}
          {property.bathrooms && (
            <div className="text-center">
              <div className="font-semibold">{property.bathrooms}</div>
              <div className="text-muted-foreground text-xs">Baths</div>
            </div>
          )}
          {property.squareFeet && (
            <div className="text-center">
              <div className="font-semibold">{property.squareFeet}</div>
              <div className="text-muted-foreground text-xs">Sq Ft</div>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Link href={`/properties/${property.id}`} className="flex-1">
            <Button variant="outline" className="w-full">
              Edit
            </Button>
          </Link>
          <Button variant="outline" className="text-destructive">
            Delete
          </Button>
        </div>
      </div>
    </div>
  )
}
