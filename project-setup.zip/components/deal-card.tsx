'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { formatCurrency } from '@/lib/utils'

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  in_progress: 'bg-blue-100 text-blue-800',
  closed: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
}

export default function DealCard({ deal }: { deal: any }) {
  const statusColor = statusColors[deal.dealStatus] || 'bg-gray-100 text-gray-800'

  return (
    <div className="border rounded-lg p-6 bg-card hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-semibold text-lg mb-1">
            {deal.dealType === 'sale' ? 'Sale Deal' : 'Rental Deal'}
          </h3>
          <p className="text-sm text-muted-foreground">
            {deal.buyerName || deal.renterName || 'No client assigned'}
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColor}`}>
          {deal.dealStatus.replace('_', ' ')}
        </span>
      </div>

      {deal.commissionAmount && (
        <p className="text-lg font-bold mb-4 text-primary">
          Commission: {formatCurrency(deal.commissionAmount)}
        </p>
      )}

      <div className="flex gap-2">
        <Link href={`/deals/${deal.id}`} className="flex-1">
          <Button variant="outline" className="w-full">
            View Details
          </Button>
        </Link>
        <Button variant="outline">Edit</Button>
      </div>
    </div>
  )
}
