import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { formatCurrency } from '@/lib/utils'

interface SourcedLeadCardProps {
  lead: {
    id: string
    buyerName: string | null
    buyerEmail: string
    budget: string | null
    location: string | null
    propertyType: string | null
    leadStatus: string
    createdAt: Date
  }
}

export function SourcedLeadCard({ lead }: SourcedLeadCardProps) {
  const statusColor = {
    new: 'bg-blue-50 text-blue-700',
    matched: 'bg-green-50 text-green-700',
    pending: 'bg-yellow-50 text-yellow-700',
    deal_created: 'bg-purple-50 text-purple-700',
    closed: 'bg-gray-50 text-gray-700',
  }[lead.leadStatus] || 'bg-gray-50 text-gray-700'

  return (
    <div className="border rounded-lg p-4 bg-card hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-semibold">{lead.buyerName || 'Buyer'}</h3>
          <p className="text-sm text-muted-foreground">{lead.buyerEmail}</p>
        </div>
        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${statusColor}`}>
          {lead.leadStatus}
        </span>
      </div>

      <div className="space-y-2 mb-4 text-sm">
        <p>
          <span className="text-muted-foreground">Budget:</span>{' '}
          <span className="font-medium">{formatCurrency(lead.budget)}</span>
        </p>
        {lead.location && (
          <p>
            <span className="text-muted-foreground">Location:</span>{' '}
            <span className="font-medium">{lead.location}</span>
          </p>
        )}
        {lead.propertyType && (
          <p>
            <span className="text-muted-foreground">Type:</span>{' '}
            <span className="font-medium">{lead.propertyType}</span>
          </p>
        )}
      </div>

      <div className="flex gap-2">
        <Link href={`/middleman/leads/${lead.id}`} className="flex-1">
          <Button variant="outline" className="w-full">View Details</Button>
        </Link>
        <Link href={`/middleman/leads/${lead.id}/match`} className="flex-1">
          <Button className="w-full">Match Property</Button>
        </Link>
      </div>
    </div>
  )
}
