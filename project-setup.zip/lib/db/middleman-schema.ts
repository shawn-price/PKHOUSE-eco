import { pgTable, text, timestamp, boolean, decimal, integer, json } from 'drizzle-orm/pg-core'

// Middleman profiles
export const middlemen = pgTable('middlemen', {
  id: text('id').primaryKey(),
  email: text('email').notNull().unique(),
  phoneNumber: text('phoneNumber').notNull(),
  firstName: text('firstName').notNull(),
  lastName: text('lastName').notNull(),
  bio: text('bio'),
  location: text('location'),
  verificationStatus: text('verificationStatus').default('pending'),
  geolocationVerified: boolean('geolocationVerified').default(false),
  lastKnownLocation: json('lastKnownLocation'),
  commissionRate: decimal('commissionRate', { precision: 5, scale: 2 }).default('30.00'),
  walletBalance: decimal('walletBalance', { precision: 15, scale: 2 }).default('0.00'),
  totalEarnings: decimal('totalEarnings', { precision: 15, scale: 2 }).default('0.00'),
  rating: decimal('rating', { precision: 3, scale: 2 }).default('5.00'),
  dealsCompleted: integer('dealsCompleted').default(0),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Leads sourced by middlemen
export const sourcedLeads = pgTable('sourcedLeads', {
  id: text('id').primaryKey(),
  middlemanId: text('middlemanId').notNull(),
  leadId: text('leadId').notNull(),
  buyerName: text('buyerName'),
  buyerEmail: text('buyerEmail').notNull(),
  buyerPhone: text('buyerPhone'),
  budget: decimal('budget', { precision: 15, scale: 2 }),
  location: text('location'),
  propertyType: text('propertyType'),
  moveInDate: timestamp('moveInDate'),
  leadStatus: text('leadStatus').default('new'),
  sourceChannel: text('sourceChannel'),
  notes: text('notes'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Property matches for sourced leads
export const leadPropertyMatches = pgTable('leadPropertyMatches', {
  id: text('id').primaryKey(),
  sourcedLeadId: text('sourcedLeadId').notNull(),
  propertyId: text('propertyId').notNull(),
  agentId: text('agentId').notNull(),
  matchScore: decimal('matchScore', { precision: 3, scale: 2 }),
  matchStatus: text('matchStatus').default('pending'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Deals involving middlemen
export const middlemanDeals = pgTable('middlemanDeals', {
  id: text('id').primaryKey(),
  middlemanId: text('middlemanId').notNull(),
  dealId: text('dealId').notNull(),
  agentId: text('agentId').notNull(),
  propertyId: text('propertyId').notNull(),
  commissionPercentage: decimal('commissionPercentage', { precision: 5, scale: 2 }).default('30.00'),
  dealStatus: text('dealStatus').default('pending'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Commission tracking for middlemen
export const middlemanCommissions = pgTable('middlemanCommissions', {
  id: text('id').primaryKey(),
  middlemanId: text('middlemanId').notNull(),
  dealId: text('dealId').notNull(),
  agentCommission: decimal('agentCommission', { precision: 15, scale: 2 }).notNull(),
  middlemanCommissionAmount: decimal('middlemanCommissionAmount', { precision: 15, scale: 2 }).notNull(),
  escrowAmount: decimal('escrowAmount', { precision: 15, scale: 2 }),
  commissionStatus: text('commissionStatus').default('pending'),
  escrowReleaseDate: timestamp('escrowReleaseDate'),
  releasedAt: timestamp('releasedAt'),
  notes: text('notes'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Real-time messaging between middlemen and agents
export const middlemanMessages = pgTable('middlemanMessages', {
  id: text('id').primaryKey(),
  dealId: text('dealId').notNull(),
  senderId: text('senderId').notNull(),
  senderType: text('senderType').notNull(),
  recipientId: text('recipientId').notNull(),
  content: text('content').notNull(),
  attachmentUrl: text('attachmentUrl'),
  messageStatus: text('messageStatus').default('sent'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
})

// Geolocation verification for fraud prevention
export const geolocationVerifications = pgTable('geolocationVerifications', {
  id: text('id').primaryKey(),
  middlemanId: text('middlemanId').notNull(),
  dealId: text('dealId'),
  propertyAddress: text('propertyAddress').notNull(),
  latitude: decimal('latitude', { precision: 10, scale: 8 }),
  longitude: decimal('longitude', { precision: 11, scale: 8 }),
  verificationTime: timestamp('verificationTime').notNull(),
  verificationStatus: text('verificationStatus').default('pending'),
  distance: decimal('distance', { precision: 8, scale: 2 }),
  verifiedAt: timestamp('verifiedAt'),
  notes: text('notes'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
})
