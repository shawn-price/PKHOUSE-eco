import { pgTable, text, timestamp, boolean, decimal, integer } from 'drizzle-orm/pg-core'

// --- Better Auth required tables -------------------------------------------
// Column names are camelCase to match Better Auth's defaults. Do not rename.

export const user = pgTable('user', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  emailVerified: boolean('emailVerified').notNull().default(false),
  image: text('image'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

export const session = pgTable('session', {
  id: text('id').primaryKey(),
  expiresAt: timestamp('expiresAt').notNull(),
  token: text('token').notNull().unique(),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
  ipAddress: text('ipAddress'),
  userAgent: text('userAgent'),
  userId: text('userId')
    .notNull()
    .references(() => user.id, { onDelete: 'cascade' }),
})

export const account = pgTable('account', {
  id: text('id').primaryKey(),
  accountId: text('accountId').notNull(),
  providerId: text('providerId').notNull(),
  userId: text('userId')
    .notNull()
    .references(() => user.id, { onDelete: 'cascade' }),
  accessToken: text('accessToken'),
  refreshToken: text('refreshToken'),
  idToken: text('idToken'),
  accessTokenExpiresAt: timestamp('accessTokenExpiresAt'),
  refreshTokenExpiresAt: timestamp('refreshTokenExpiresAt'),
  scope: text('scope'),
  password: text('password'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

export const verification = pgTable('verification', {
  id: text('id').primaryKey(),
  identifier: text('identifier').notNull(),
  value: text('value').notNull(),
  expiresAt: timestamp('expiresAt').notNull(),
  createdAt: timestamp('createdAt').defaultNow(),
  updatedAt: timestamp('updatedAt').defaultNow(),
})

// --- App tables ------------------------------------------------------------
// Add your app tables below. Always include a plain `userId` column so queries
// can be scoped per user — the security model depends on this column existing,
// not on a foreign key. Do NOT add a foreign key constraint
// (`.references(() => user.id, ...)`) unless the user explicitly asks for
// foreign keys or referential integrity; FK constraints make iterating on the
// schema harder.
//
// Example:
//
// import { serial } from "drizzle-orm/pg-core"
//
// export const todos = pgTable("todos", {
//   id: serial("id").primaryKey(),
//   userId: text("userId").notNull(),
//   title: text("title").notNull(),
//   completed: boolean("completed").notNull().default(false),
//   createdAt: timestamp("createdAt").notNull().defaultNow(),
// })
//
// If the user asks for foreign keys, add the reference back in:
//   userId: text("userId")
//     .notNull()
//     .references(() => user.id, { onDelete: "cascade" }),

// Agent profiles
export const agents = pgTable('agents', {
  id: text('id').primaryKey(),
  userId: text('userId').notNull(),
  licenseNumber: text('licenseNumber').unique(),
  licenseVerified: boolean('licenseVerified').notNull().default(false),
  companyName: text('companyName'),
  phoneNumber: text('phoneNumber'),
  bio: text('bio'),
  verificationStatus: text('verificationStatus').default('pending'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Properties (listings)
export const properties = pgTable('properties', {
  id: text('id').primaryKey(),
  agentId: text('agentId').notNull(),
  userId: text('userId').notNull(),
  title: text('title').notNull(),
  description: text('description'),
  address: text('address').notNull(),
  city: text('city'),
  state: text('state'),
  zipCode: text('zipCode'),
  price: decimal('price', { precision: 15, scale: 2 }),
  propertyType: text('propertyType'),
  bedrooms: integer('bedrooms'),
  bathrooms: integer('bathrooms'),
  squareFeet: integer('squareFeet'),
  imageUrls: text('imageUrls').array(),
  listingStatus: text('listingStatus').default('active'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Deals (transactions between agents)
export const deals = pgTable('deals', {
  id: text('id').primaryKey(),
  propertyId: text('propertyId').notNull(),
  sellingAgentId: text('sellingAgentId').notNull(),
  buyingAgentId: text('buyingAgentId').notNull(),
  buyerName: text('buyerName'),
  renterName: text('renterName'),
  dealType: text('dealType').notNull(),
  commissionAmount: decimal('commissionAmount', { precision: 15, scale: 2 }),
  dealStatus: text('dealStatus').default('pending'),
  closedAt: timestamp('closedAt'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Commission tracking and ledger
export const commissions = pgTable('commissions', {
  id: text('id').primaryKey(),
  dealId: text('dealId').notNull(),
  agentId: text('agentId').notNull(),
  amount: decimal('amount', { precision: 15, scale: 2 }).notNull(),
  commissionStatus: text('commissionStatus').default('pending'),
  escrowAmount: decimal('escrowAmount', { precision: 15, scale: 2 }),
  escrowReleaseDate: timestamp('escrowReleaseDate'),
  notes: text('notes'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Agent partnerships and collaboration
export const partnerships = pgTable('partnerships', {
  id: text('id').primaryKey(),
  agent1Id: text('agent1Id').notNull(),
  agent2Id: text('agent2Id').notNull(),
  status: text('status').default('pending'),
  commissionSplit: decimal('commissionSplit', { precision: 5, scale: 2 }).default('50.00'),
  notes: text('notes'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Deal rooms for collaboration
export const dealRooms = pgTable('dealRooms', {
  id: text('id').primaryKey(),
  dealId: text('dealId').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Messages in deal rooms
export const messages = pgTable('messages', {
  id: text('id').primaryKey(),
  dealRoomId: text('dealRoomId').notNull(),
  userId: text('userId').notNull(),
  content: text('content').notNull(),
  createdAt: timestamp('createdAt').notNull().defaultNow(),
})
