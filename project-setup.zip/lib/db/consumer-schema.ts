import { pgTable, text, timestamp, boolean, decimal, integer, email } from 'drizzle-orm/pg-core'

// Leads table - write-only for consumer site
export const leads = pgTable('leads', {
  id: text('id').primaryKey(),
  propertyId: text('propertyId').notNull(),
  email: text('email').notNull(),
  phone: text('phone'),
  firstName: text('firstName'),
  lastName: text('lastName'),
  interestLevel: text('interestLevel').default('interested'), // interested, very_interested, serious
  message: text('message'),
  contactPreference: text('contactPreference').default('email'), // email, phone, both
  leadStatus: text('leadStatus').default('new'), // new, contacted, qualified, lost
  createdAt: timestamp('createdAt').notNull().defaultNow(),
  updatedAt: timestamp('updatedAt').notNull().defaultNow(),
})

// Saved properties for wishlist/favorites
export const savedProperties = pgTable('savedProperties', {
  id: text('id').primaryKey(),
  propertyId: text('propertyId').notNull(),
  visitorId: text('visitorId').notNull(), // Anonymous visitor tracking ID
  createdAt: timestamp('createdAt').notNull().defaultNow(),
})
